# AI Study Buddy
Upload this folder to GitHub. Open Actions and run **Build AI Study Buddy APK**. When complete, open the run and download the **AI-Study-Buddy-APK** artifact, then extract `app-debug.apk` on your Android phone.
